from .Pan_Extractor import Pan_Info_Extractor
from .Aadhar_Extractor import Aadhar_Info_Extractor
